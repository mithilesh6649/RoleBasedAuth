<a href="{{ route('show.in.genre', $genre->id) }}">
<div class="image-category">
    <div class="item slider-images-home position-relative">
        @if ($genre->image != null)
            <img src="{{ asset('images/genre/' . $genre->image) }}"
                class="slider-images" />
        @else
                
            <img src="{{ asset('/images/default-thumbnail.jpg') }}"
                class="slider-images" />
        @endif
    </div>
    <h3 class="image-category-heading text-white text-center">
        {{ $genre->name }}
    </h3>
</div>
</a>