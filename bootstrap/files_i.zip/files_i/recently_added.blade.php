<div class="container my-5">
    <div class="row">
        <div class="col-12">
            <div class="row">
                <div class="col-6 d-flex align-items-center gap-2">
                    <h4 class="first-sider-heading">Infotainment</h4>
                    <a href="#" class="view-all-images text-decoration-none ms-3 border">View all</a>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="home-demo position-relative">
                <div class="owl-carousel owl-theme">
                    <div class="hovereffect-img position-relative">
                        <div class="item slider-images-home">
                            <img src="{{ asset('assets_new/img/Infotainment1.png') }}" class="slider-images" />
                        </div>
                        <div class="hoverr-opacity p-3">
                            <h3 class="moviename-heading text-white">Pathan </h3>
                            <div class="d-flex align-items-center gap-3 flex-wrap">
                                <h4 class="moviedetail-text text-white">Rating</h4>
                                <h4 class="moviedetail-text  text-white">30 Mins</h4>
                                <h4 class="moviedetail-text  text-white">2024</h4>
                                <h4 class="moviedetail-text  text-white">All age</h4>
                            </div>
                            <div class="mb-2">
                                <a href="#" class="read-button text-decoration-none ">Read More</a>
                            </div>
                            <div>
                                <a href="#" class="trailer-button text-decoration-none  border"> Watch
                                    Trailer</a>
                            </div>
                        </div>
                    </div>
                    <div class="item slider-images-home">
                        <img src="{{ asset('assets_new/img/Infotainment2.png') }}" class="slider-images" />
                    </div>
                    <div class="item slider-images-home">
                        <img src="{{ asset('assets_new/img/Infotainment3.png') }}" class="slider-images" />
                    </div>
                    <div class="item slider-images-home">
                        <img src="{{ asset('assets_new/img/Infotainment4.png') }}" class="slider-images" />
                    </div>
                    <div class="item slider-images-home">
                        <img src="{{ asset('assets_new/img/Infotainment5.png') }}" class="slider-images" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
