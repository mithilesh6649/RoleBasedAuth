<div class="hovereffect-img position-relative">
    {{-- lable and video img  start--}}

    <div class="item slider-images-home">
        @if (@$item->is_custom_label === 1 && isset($item->label_id))
        <div class="image-label-album">
            <h3 class="label-heading text-white text-center mb-0">
                {{ $item->label->name }}
            </h3>
        </div>
       @endif

      
       <a  @if (isset($gets1)) href="{{ url('show/guest/detail', $gets1->season_slug) }}    " @endif>
        @isset($src)
            <img src="{{ $src }}" class="slider-images" alt="genre-image" />
        @endisset
    </a>
    </div>

    {{-- lable and video img end --}}
     
    {{-- Prop start --}}
    @if (isset($protip) && $protip == 1)
        <div class="hoverr-opacity p-3">
        
            <h3 class="moviename-heading text-white">{{ $item->title }}</h3>
            <div class="d-flex align-items-center gap-3 flex-wrap">
                <h4 class="moviedetail-text text-white">{{ __('Tmdb Rating') }} {{ $item->rating }}</h4>
                <h4 class="moviedetail-text text-white">{{ __('Season') }} {{ $item->season_no }}</h4>
                <h4 class="moviedetail-text text-white">{{ $item->publish_year }}</h4>
                <h4 class="moviedetail-text text-white">{{ $item->age_req }}</h4>
                {{-- <h4 class="moviedetail-text text-white">{{ str_limit($item->detail, 100, '...') }}</h4> --}}
            </div>

        <!-- Read More Button -->
        <div class="mb-2">
            <a href="{{ url('show/guest/detail', $item->season_slug) }}" class="read-button text-decoration-none">Read More</a>
        </div>

        <!-- Play Now and Watch Trailer Buttons -->
        {{-- <div class="mb-3">
            <div class="playNow-btn mb-3">
                <a href="#" class="text-decoration-none text-white d-flex align-items-center gap-3">
                    <span class="play-icon d-flex align-items-center justify-content-center">
                    <i class="fa-solid fa-play"></i>
                </span>
                <span>Play Now</span>
             </a>
            </div>

          <a href="#" class="trailer-button text-decoration-none border d-block">Watch Trailer</a>
         </div> --}}

        


            @if ($gets1->trailer_url != null || $gets1->trailer_url != '')
              <div class="mb-3">
                <a href="{{ route('guestwatchtvtrailer', $gets1->id) }}" class="trailer-button text-decoration-none border d-block"> {{ __('Watch Trailer') }}</a>
               </div>
            @endif

    <!-- Add to Watchlist Button -->
   
</div>

    @endif
    {{-- Prop end --}}
  </div>