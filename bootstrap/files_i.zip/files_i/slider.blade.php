   {{-- @if (isset($home_slides) && count($home_slides) > 0)
       <div class="swiper-container mt-4 pb-4">
           <div class="swiper-wrapper">
                 @foreach ($home_slides as $slide)
                   @if ($slide->active == 1)
                       <div class="swiper-slide first-slide">
                           <a href="#">
                               <img src="{{ asset('assets_new/img/carousel-img-1.png') }}">
                           </a>
                       </div>
                   @endif
               @endforeach  

               <div class="swiper-slide first-slide">
                   <img src="{{ asset('assets_new/img/carousel-img-1.png') }}">
               </div>
               <div class="swiper-slide first-slide">
                   <img src="{{ asset('assets_new/img/carousel-img-2.png') }}">
               </div>
               <div class="swiper-slide first-slide">
                   <img src="{{ asset('assets_new/img/carousel-img-2.png') }}">
               </div>

               <div class="swiper-slide first-slide">
                   <img src="{{ asset('assets_new/img/carousel-img-2.png') }}">
               </div>


           </div>
           <div class="swiper-pagination"></div>
       </div>
   @endif --}}


   @if (isset($home_slides) && count($home_slides) > 0)
       <div class="swiper-container mt-4 pb-4">
           <div class="swiper-wrapper">
               @foreach ($home_slides as $slide)
                   @if ($slide->active == 1)
                       <div class="swiper-slide first-slide">
                           @if ($slide->movie_id != null)
                               @if (isset($auth) && getSubscription()->getData()->subscribed == true)
                                   <a
                                       href="{{ isset($slide->movie) && $slide->movie != null ? url('movie/detail', $slide->movie->slug) : '#' }}">
                                       @if ($slide->slide_image != null)
                                           @php
                                               $image = 'images/home_slider/movies/' . $slide->slide_image;
                                               $imageData = base64_encode(@file_get_contents($image));
                                               $src = $imageData
                                                   ? 'data: ' . mime_content_type($image) . ';base64,' . $imageData
                                                   : '';
                                           @endphp
                                           <img src="{{ $src }}" class="img-responsive" alt="slider-image">
                                       @elseif ($slide->movie->poster != null)
                                           @php
                                               $image = 'images/movies/posters/' . $slide->movie->poster;
                                               $imageData = base64_encode(@file_get_contents($image));
                                               $src = $imageData
                                                   ? 'data: ' . mime_content_type($image) . ';base64,' . $imageData
                                                   : '';
                                           @endphp
                                           <img src="{{ $src }}" class="img-responsive" alt="slider-image">
                                       @endif
                                   </a>
                               @else
                                   <a
                                       href="{{ isset($slide->movie) && $slide->movie != null ? url('movie/guest/detail', $slide->movie->slug) : '#' }}">
                                       @if ($slide->slide_image != null)
                                           @php
                                               $image = 'images/home_slider/movies/' . $slide->slide_image;
                                               $imageData = base64_encode(@file_get_contents($image));
                                               $src = $imageData
                                                   ? 'data: ' . mime_content_type($image) . ';base64,' . $imageData
                                                   : '';
                                           @endphp
                                           <img src="{{ $src }}" class="img-responsive" alt="slider-image">
                                       @elseif ($slide->movie->poster != null)
                                           @php
                                               $image = 'images/movies/posters/' . $slide->movie->poster;
                                               $imageData = base64_encode(@file_get_contents($image));
                                               $src = $imageData
                                                   ? 'data: ' . mime_content_type($image) . ';base64,' . $imageData
                                                   : '';
                                           @endphp
                                           <img src="{{ $src }}" class="img-responsive" alt="slider-image">
                                       @endif
                                   </a>
                               @endif
                           @elseif($slide->tv_series_id != null)
                               @if ($auth && getSubscription()->getData()->subscribed == true)
                                   <a
                                       href="{{ isset($slide->tvseries->seasons[0]) && $slide->tvseries->seasons[0] != null ? url('show/detail', $slide->tvseries->seasons[0]->season_slug) : '#' }}">
                                       @if ($slide->slide_image != null)
                                           <img src="{{ url('images/home_slider/shows/' . $slide->slide_image) }}"
                                               class="img-responsive" alt="slider-image">
                                       @elseif ($slide->tvseries->poster != null)
                                           <img src="{{ url('images/tvseries/posters/' . $slide->tvseries->poster) }}"
                                               class="img-responsive" alt="slider-image">
                                       @endif
                                   </a>
                               @else
                                   <a
                                       href="{{ isset($slide->tvseries->seasons[0]) && $slide->tvseries->seasons[0] != null ? url('show/guest/detail', $slide->tvseries->seasons[0]->season_slug) : '#' }}">
                                       @if ($slide->slide_image != null)
                                           <img src="{{ url('images/home_slider/shows/' . $slide->slide_image) }}"
                                               class="img-responsive" alt="slider-image">
                                       @elseif ($slide->tvseries->poster != null)
                                           <img src="{{ url('images/tvseries/posters/' . $slide->tvseries->poster) }}"
                                               class="img-responsive" alt="slider-image">
                                       @endif
                                   </a>
                               @endif
                           @else
                               <a href="#">
                                   @if ($slide->slide_image != null)
                                       <img src="{{ url('images/home_slider/' . $slide->slide_image) }}"
                                           class="img-responsive" alt="slider-image">
                                   @endif
                               </a>
                           @endif
                       </div>
                   @endif
               @endforeach
           </div>
           <div class="swiper-pagination"></div>
       </div>
   @endif
