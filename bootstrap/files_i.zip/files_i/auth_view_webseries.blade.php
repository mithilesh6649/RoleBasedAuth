<div class="hovereffect-img position-relative">
    <div class="item slider-images-home">
        {{-- Display custom label if applicable --}}
        @if (@$item->is_custom_label === 1 && isset($item->label_id))
            <div class="image-label-album">
                <h3 class="label-heading text-white text-center mb-0">
                    {{ $item->label->name }}
                </h3>
            </div>
        @endif

        {{-- Movie image --}}
        <a  @if (isset($gets1)) href="{{ url('show/detail', $gets1->season_slug) }}" @endif>
            @isset($src)
                <img src="{{ $src }}" class="slider-images" alt="genre-image" />
            @endisset
        </a>

        {{-- Hide  --}}
        {{-- <div class="hide-icon">
            <a onclick="hideforme('{{ $gets1->id }}','{{ $gets1->type }}')"
                title="{{ __('Hide this Movie') }}"
                class=""><i
                    class="fa fa-eye-slash"></i></a>
        </div> --}}
        {{--  Hide --}}
    </div>

    {{-- Movie details and actions --}}
    @if (isset($protip) && $protip == 1)
        <div class="hoverr-opacity p-3">
            <h3 class="moviename-heading text-white">{{ $item->title }}</h3>
            <div class="d-flex align-items-center gap-3 flex-wrap">
                <h4 class="moviedetail-text text-white">{{ __('Tmdb Rating') }} {{ $item->rating }}</h4>
                <h4 class="moviedetail-text text-white">{{ __('Season') }} {{ $item->season_no }}</h4>
                <h4 class="moviedetail-text text-white">{{ $item->publish_year }}</h4>
                <h4 class="moviedetail-text text-white">{{ $item->age_req }}</h4>
                {{-- <h4 class="moviedetail-text text-white">{{ str_limit($item->detail, 100, '...') }}</h4> --}}
            </div>
            <div class="mb-2">
                <a href="{{ url('show/detail', $item->season_slug) }}" class="read-button text-decoration-none">
                    {{ __('Read More') }}
                </a>
            </div>

            {{-- Play Now Button --}}
            {{-- @if ($item->is_upcoming == 0 && checkInMovie($item) && isset($item->video_link))
                @if ($item->maturity_rating == 'all age' || $age >= str_replace('+', '', $item->maturity_rating))
                    @if (isset($item->video_link['iframeurl']) && $item->video_link['iframeurl'])
                        <div class="mb-3">
                            <div class="playNow-btn mb-3">
                                <a href="{{ route('watchmovieiframe', $item->id) }}"
                                    class="text-decoration-none text-white d-flex align-items-center gap-3">
                                    <span class="play-icon d-flex align-items-center justify-content-center">
                                        <i class="fa-solid fa-play"></i>
                                    </span>
                                    <span>{{ __('Play Now') }}</span>
                                </a>
                            </div>
                        </div>
                    @else
                        <div class="mb-3">
                            <div class="playNow-btn mb-3">
                                <a href="{{ route('watchmovie', $item->id) }}"
                                    class="text-decoration-none text-white d-flex align-items-center gap-3">
                                    <span class="play-icon d-flex align-items-center justify-content-center">
                                        <i class="fa-solid fa-play"></i>
                                    </span>
                                    <span>{{ __('Play Now') }}</span>
                                </a>
                            </div>
                        </div>
                    @endif
                @endif
            @endif --}}

            @if (isset($gets1->episodes[0]) && checkInTvseries($item) == true && isset($gets1->episodes[0]->video_link))
            @if ($item->age_req == 'all age' || $age >= str_replace('+', '', $item->age_req))
                @if ($gets1->episodes[0]->video_link['iframeurl'] != '')
                     {{-- <a href="#"
                        onclick="playoniframe('{{ $gets1->episodes[0]->video_link['iframeurl'] }}','{{ $gets1->episodes[0]->seasons->tvseries->id }}','tv')"
                        class="btn btn-play"><span
                            class= "play-btn-icon"><i
                                class="fa fa-play"></i></span>
                        <span
                            class="play-text">{{ __('Play Now') }}</span>
                    </a>  --}}
                    
                    
                    <div class="mb-3">
                        <div class="playNow-btn mb-3">
                            <a   onclick="playoniframe('{{ $gets1->episodes[0]->video_link['iframeurl'] }}','{{ $gets1->episodes[0]->seasons->tvseries->id }}','tv')"
                                class="text-decoration-none text-white d-flex align-items-center gap-3">
                                <span class="play-icon d-flex align-items-center justify-content-center">
                                    <i class="fa-solid fa-play"></i>
                                </span>
                                <span>{{ __('Play Now') }}</span>
                            </a>
                        </div>
                    </div>
                @else
                    
                <div class="mb-3">
                    <div class="playNow-btn mb-3">
                        <a href="{{ route('watchTvShow', $gets1->id) }}"
                            class="text-decoration-none text-white d-flex align-items-center gap-3">
                            <span class="play-icon d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-play"></i>
                            </span>
                            <span>{{ __('Play Now') }}</span>
                        </a>
                    </div>
                </div>
                @endif
            @else
                <a onclick="myage({{ $age }})"
                    class=" btn btn-play"><span
                        class="play-btn-icon"><i
                            class="fa fa-play"></i></span>
                    <span
                        class="play-text">{{ __('Play Now') }}</span></a>
            @endif
        @endif
        

            {{-- Watch Trailer Button --}}
            @if ($gets1->trailer_url != null || $gets1->trailer_url != '')
                <div class="mb-3">
                    <a href="{{ route('watchtvTrailer', $gets1->id) }}"
                        class="trailer-button text-decoration-none border d-block">
                        {{ __('Watch Trailer') }}
                    </a>
                </div>
            @endif

            {{-- Add/Remove from Watchlist Button --}}
            


            @php
            // Determine if the user is subscribed
            $isSubscribed = getSubscription()->getData()->subscribed == true;
        
            // Determine if the movie is in the watchlist
            $isInWatchlist = isset($wishlist_check->added) && $wishlist_check->added == 1;
        
            // Define the button text based on watchlist status
            $buttonText = $isInWatchlist ? __('Remove From Watchlist') : __('Add to Watchlist');
        @endphp
        
        @if (($catlog == 0 && $isSubscribed) || ($catlog == 1 && $auth))
            @if (isset($gets1))
                <a
                    onclick="addWish({{ $gets1->id }},'{{ $gets1->type }}')"
                    class="addwishlistbtn{{ $gets1->id }}{{ $gets1->type }} btn-default watchlist-button text-decoration-none border d-block">
                    {{ $buttonText }}
                </a>
            @endif
        @endif
        

            {{-- Progress Bar --}}
            @if (timecalcuate($auth->id, $item->id, $item->type) != 0)
                <div class="progress-bar-container mt-3">
                    <div class="progress" style="height: 5px;">
                        <div class="progress-bar bg-primary" role="progressbar"
                            style="width: {{ timecalcuate($auth->id, $item->id, $item->type) }}%;"
                            aria-valuenow="{{ timecalcuate($auth->id, $item->id, $item->type) }}" aria-valuemin="0"
                            aria-valuemax="100"></div>
                    </div>
                </div>
            @endif
        </div>
    @endif
</div>
