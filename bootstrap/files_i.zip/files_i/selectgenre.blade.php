<link href="{{ url('css/owl.carousel.min.css') }}" rel="stylesheet" type="text/css" /> <!-- owl carousel css -->
<link href="{{ url('css/owl.theme.default.min.css') }}" rel="stylesheet" type="text/css" /> <!-- owl carousel css -->


@foreach ($menu->menugenreshow->sortBy('genre.position') as $genre)
    @if (isset($genre->genre) && $genre->genre != null)
        @php
            $moviegenreitems = null;
            $moviegenreitems = [];

            foreach ($menu_data as $key => $item) {
                $gmovie = App\Movie::join('videolinks', 'videolinks.movie_id', '=', 'movies.id')
                    ->select(
                        'movies.id as id',
                        'movies.title as title',
                        'movies.type as type',
                        'movies.status as status',
                        'movies.genre_id as genre_id',
                        'movies.thumbnail as thumbnail',
                        'movies.rating as rating',
                        'movies.duration as duration',
                        'movies.publish_year as publish_year',
                        'movies.maturity_rating as maturity_rating',
                        'movies.detail as detail',
                        'movies.trailer_url as trailer_url',
                        'videolinks.iframeurl as iframeurl',
                        'movies.slug as slug',
                        'movies.tmdb as tmdb',
                        'movies.is_custom_label as is_custom_label',
                        'movies.label_id as label_id',
                    )
                    ->where('movies.is_upcoming', '!=', 1)
                    ->where('movies.id', $item->movie_id)
                    ->first();
                if (isset($gmovie->genre_id)) {
                    foreach (explode(',', $gmovie->genre_id) as $key => $ggid) {
                        if ($ggid == $genre->genre->id) {
                            if (isset($gmovie) && $gmovie != null) {
                                $moviegenreitems[] = $gmovie;
                            }
                        }
                    }
                }

                if ($section->order == 1) {
                    arsort($moviegenreitems);
                }

                if (count($moviegenreitems) == $section->item_limit) {
                    break;
                    exit(1);
                }
            }
            $moviegenreitems = array_values(array_filter($moviegenreitems));
            foreach ($menu_data as $key => $item) {
                $gtvs = App\Tvseries::join('seasons', 'seasons.tv_series_id', '=', 'tv_series.id')
                    ->join('episodes', 'episodes.seasons_id', '=', 'seasons.id')
                    ->join('videolinks', 'videolinks.episode_id', '=', 'episodes.id')
                    ->select(
                        'seasons.id as seasonid',
                        'tv_series.genre_id as genre_id',
                        'tv_series.id as id',
                        'tv_series.type as type',
                        'tv_series.status as status',
                        'tv_series.thumbnail as thumbnail',
                        'tv_series.title as title',
                        'tv_series.rating as rating',
                        'seasons.publish_year as publish_year',
                        'tv_series.maturity_rating as age_req',
                        'tv_series.detail as detail',
                        'seasons.season_no as season_no',
                        'videolinks.iframeurl as iframeurl',
                        'seasons.trailer_url as trailer_url',
                        'seasons.tmdb as tmdb',
                        'tv_series.is_custom_label as is_custom_label',
                        'tv_series.label_id as label_id',
                    )

                    ->where('tv_series.id', $item->tv_series_id)
                    ->first();

                if (isset($gtvs->genre_id)) {
                    foreach (explode(',', $gtvs->genre_id) as $key => $ggtid) {
                        if ($ggtid == $genre->genre->id) {
                            if (isset($gtvs) && $gtvs != null) {
                                $moviegenreitems[] = $gtvs;
                            }
                        }
                    }
                }

                if ($section->order == 1) {
                    arsort($moviegenreitems);
                }

                if (count($moviegenreitems) == $section->item_limit * 2) {
                    break;
                    exit(1);
                }
            }
            $moviegenreitems = array_values(array_filter($moviegenreitems));

        @endphp
        {{-- <div class="genre-prime-block genre-prime-block-one genre-paddin-top">
            <div class="container-fluid"> --}}

        <div class="container my-5">
            <div class="row">

                {{-- @if ($moviegenreitems != null && count($moviegenreitems) > 0)
                    <h5 class="section-heading">{{ $genre->genre->name }} </h5>

                    @if ($auth && getSubscription()->getData()->subscribed == true)
                        <a href="{{ route('show.in.genre', $genre->genre->id) }}" class="see-more">
                            <b>{{ __('View All') }}</b></a>
                    @else
                        <a href="{{ route('show.in.guest.genre', $genre->genre->id) }}" class="see-more">
                            <b>{{ __('View All') }}</b></a>
                    @endif
                @endif --}}


                @if ($moviegenreitems != null && count($moviegenreitems) > 0)
                    <div class="col-12">
                        <div class="row">
                            <div class="col-6 d-flex align-items-center gap-2">
                                <h4 class="first-sider-heading"> {{ $genre->genre->name }}</h4>

                                @if ($auth && getSubscription()->getData()->subscribed == true)
                                    <a class="see-more view-all-images text-decoration-none ms-3 border"
                                        href="{{ route('show.in.genre', $genre->genre->id) }}">
                                        <b>{{ __('View All') }}</b></a>
                                @else
                                    <a class="see-more view-all-images text-decoration-none ms-3 border"
                                        href="{{ route('show.in.guest.genre', $genre->genre->id) }}" class="see-more">
                                        <b>{{ __('View All') }}</b></a>
                                @endif


                            </div>
                        </div>
                    </div>
                @endif




                   <!-- Recently added movies and tv shows in list view End-->
                   @if ($section->view == 1 || $section->view == 0)
                   <div class="col-12">
                       <div class="home-demo position-relative">
                           <div class="owl-carousel owl-theme">
                               @foreach ($moviegenreitems as $item)
                                   @php
                                       if (isset($auth) && $auth != null) {
                                           if ($item->type == 'M') {
                                               $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                                   'wishlists',
                                               )
                                                   ->where([
                                                       ['user_id', '=', $auth->id],
                                                       ['movie_id', '=', $item->id],
                                                   ])
                                                   ->first();
                                           }
                                       }

                                       if (isset($auth) && $auth != null) {
                                           $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();

                                           if (isset($gets1)) {
                                               $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                                   'wishlists',
                                               )
                                                   ->where([
                                                       ['user_id', '=', $auth->id],
                                                       ['season_id', '=', $gets1->id],
                                                   ])
                                                   ->first();
                                           }
                                       } else {
                                           $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();
                                       }
                                   @endphp

                                   @if ($item->status == 1)
                                       @if ($item->type == 'M')
                                           @php
                                               if ($item->thumbnail != null) {
                                                   $image =
                                                       public_path() .
                                                       '/images/movies/thumbnails/' .
                                                       $item->thumbnail;
                                               } else {
                                                   $image = Avatar::create($item->title)->toBase64();
                                               }

                                               // Read image path, convert to base64 encoding

                                               $imageData = base64_encode(@file_get_contents($image));
                                               if ($imageData) {
                                                   $src =
                                                       'data: ' .
                                                       mime_content_type($image) .
                                                       ';base64,' .
                                                       $imageData;
                                               } else {
                                                   $src = Avatar::create($item->title)->toBase64();
                                               }
                                           @endphp
                                           @if (hidedata($item->id, $item->type) != 1)
                                               {{--Working   --}}
                                               @if ($auth && getSubscription()->getData()->subscribed == true)
                                                 @include('partials.auth_view');
                                               @else
                                                 @include('partials.guest_view');
                                               @endif
                                               
                                           @endif
                                           {{-- Tv Series start --}}
                                       @elseif($item->type == 'T')
                                           @php
                                               $image = 'images/tvseries/thumbnails/' . $item->thumbnail;
                                               // Read image path, convert to base64 encoding

                                               $imageData = base64_encode(@file_get_contents($image));
                                               if ($imageData) {
                                                   // Format the image SRC:  data:{mime};base64,{data};
                                                   $src =
                                                       'data: ' .
                                                       mime_content_type($image) .
                                                       ';base64,' .
                                                       $imageData;
                                               } else {
                                                   $src = Avatar::create($item->title)->toBase64();
                                               }
                                           @endphp



                                           {{-- T --}}
                                           @if (hidedata($gets1->id, $gets1->type) != 1)

                                             @if ($auth && getSubscription()->getData()->subscribed == true)
                                               @include('partials.auth_view_webseries');
                                             @else
                                               @include('partials.guest_view_webseries');
                                             @endif

                                             
                                           @endif
                                           {{--  T --}}

                                           {{-- old   --}}
                                          
                                           {{-- old --}}
                                       @endif

                                       {{-- Tv serices end --}}
                                   @endif
                               @endforeach
                           </div>
                       </div>
                   </div>
               @endif
               <!-- Recently added movies and tv shows in list view End-->
               <!-- Recently Tvshows and movies in Grid view -->
               @if ($section->view == 0)
                   {{-- This is Pending --}}
               @endif
               <!-- Recently Tvshows and movies in Grid view END-->
 
            </div>
        </div>
    @endif
@endforeach

@section('custom-script')
    <script>
        function myage(age) {
            if (age == 0) {
                $('#ageModal').modal('show');
            } else {
                $('#ageWarningModal').modal('show');
            }
        }
    </script>
    <script type="text/javascript">
        function addWish(id, type) {
            //   app.addToWishList(id, type);
            $.ajax({
                type: 'POST',
                url: '{{ route('addtowishlist') }}',
                data: {
                    "id": id,
                    "type": type,
                    "_token": "{{ csrf_token() }}"
                },
                success: function(data) {
                    console.log(data);
                }
            });
            setTimeout(function() {
                $('.addwishlistbtn' + id + type).text(function(i, text) {
                    return text == "{{ __('Add to Watchlist') }}" ?
                        "{{ __('Remove from Watchlist') }}" : "{{ __('Add to Watchlist') }}";
                });
            }, 100);
        }
    </script>
@endsection

<script type="text/javascript" src="{{ url('js/jquery.popover.js') }}"></script> <!-- bootstrap popover js -->
<script type="text/javascript" src="{{ url('js/menumaker.js') }}"></script> <!-- menumaker js -->
<script type="text/javascript" src="{{ url('js/jquery.curtail.min.js') }}"></script> <!-- menumaker js -->
@if (selected_lang()->rtl == 0)
    <script type="text/javascript" src="{{ url('js/owl.carousel.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('js/slider.js') }}"></script>
@else
    <script type="text/javascript" src="{{ url('js/owl-carousel-rtl-js/owl.carousel.min.js') }}"></script> <!-- owl carousel js -->
    <script type="text/javascript" src="{{ url('js/slider-rtl.js') }}"></script>
@endif

<script type="text/javascript" src="{{ url('js/jquery.scrollSpeed.js') }}"></script> <!-- owl carousel js -->
<script type="text/javascript" src="{{ url('js/TweenMax.min.js') }}"></script> <!-- animation gsap js -->
<script type="text/javascript" src="{{ url('js/ScrollMagic.min.js') }}"></script> <!-- custom js -->
<script type="text/javascript" src="{{ url('js/animation.gsap.min.js') }}"></script> <!-- animation gsap js -->
<script type="text/javascript" src="{{ url('js/modernizr-custom.js') }}"></script> <!-- debug addIndicators js -->
<script type="text/javascript" src="{{ url('js/theme.js') }}"></script> <!-- custom js -->
<script type="text/javascript" src="{{ url('js/custom-js.js') }}"></script>
<script type="text/javascript" src="{{ url('js/colorbox.js') }}"></script>
<script type="text/javascript" src="{{ url('js/checkit.js') }}"></script>
{{-- start rating js --}}
<script src="{{ url('js/star-rating.min.js') }}"></script>
