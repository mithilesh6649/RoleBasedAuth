<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Qaum</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous" />

    <!-- font awesome link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.1/css/swiper.min.css" />

    <!-- font family link -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap"
        rel="stylesheet" />
    <!-- stylesheet link -->
    <link rel="stylesheet" href="{{ asset('assets_new/css/font-family.css') }}">
    <link rel="stylesheet" href="{{ asset('assets_new/css/style.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets_new/css/responsive.css') }}" />
</head>

{{-- @extends('layouts.theme')
@section('title', "$menu->name")
@section('main-wrappers') --}}

<body>
    <!-- header  -->
    <header class="site_header">
        <div class="container">
            <nav class="navbar navbar-expand-lg pt-0">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">
                        <img src="{{ asset('assets_new/img/QaumTV-logo-trans 1.png') }}" alt="logo" />
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse search-bar position-relative" id="navbarSupportedContent">


                        <form class="d-flex ms-2 w-100 mb-2 mb-lg-0">
                            @auth
                                <span class="search-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                        <path
                                            d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
                                    </svg>
                                </span>
                                <input class="form-control me-2 header-search-bar ps-5" type="search"
                                    placeholder="What are you watching today?" aria-label="Search" />
                            @endauth
                        </form>



                        <form class="d-flex gap-3" role="search">
                            <a href="{{ url('login') }}" class="btn btn-transparent" style="white-space: nowrap;">Sign
                                in</a>
                            <a href="{{ url('register') }}" class="btn btn-primary" style="white-space: nowrap;"
                                type="submit">Register</a>
                        </form>
                    </div>

                </div>
            </nav>
        </div>
    </header>
    <!-- header end -->


    <!-- Slider main container start -->
    @include('partials.slider')


    <!-- Slider main container end -->

    <!-- age modal -->
    @include('modal.agemodal')
    <!--- end age modal -->

    <!-- age warning modal -->
    @include('modal.agewarning')
    <!-- end age warning modal -->


    {{--  --}}
    @if (count($menu->menusections) > 0)
        {{-- 1111 --}}

        @foreach ($menu->menusections as $section)
            @php
                foreach ($recent_data as $key => $item) {
                    $d = \Request::getHost();
                    $domain = str_replace('www.', '', $d);
                    if (strstr($domain, 'localhost')) {
                        $ipaddress = '43.251.92.73';
                    } else {
                        $ipaddress = $request->getClientIp();
                        $ipaddress = $ipaddress == '::1' ? '43.251.92.73' : $ipaddress;
                    }
                    $geoip = geoip()->getLocation($ipaddress);
                    $usercountry = strtoupper($geoip->country);

                    $rm = App\Movie::join('videolinks', 'videolinks.movie_id', '=', 'movies.id')
                        ->select(
                            'movies.id as id',
                            'movies.title as title',
                            'movies.type as type',
                            'movies.status as status',
                            'movies.genre_id as genre_id',
                            'movies.thumbnail as thumbnail',
                            'movies.live as live',
                            'movies.rating as rating',
                            'movies.duration as duration',
                            'movies.publish_year as publish_year',
                            'movies.maturity_rating as maturity_rating',
                            'movies.detail as detail',
                            'movies.trailer_url as trailer_url',
                            'videolinks.iframeurl as iframeurl',
                            'movies.slug as slug',
                            'movies.tmdb as tmdb',
                            'movies.is_custom_label as is_custom_label',
                            'movies.label_id as label_id',
                        )
                        ->where('movies.is_upcoming', '!=', 1)
                        ->where('movies.is_kids', '!=', 1)
                        ->where('movies.country', 'NOT like', '%' . $usercountry . '%')
                        ->where('movies.id', $item->movie_id)
                        ->first();

                    $recentlyadded[] = $rm;

                    if ($section->order == 1) {
                        arsort($recentlyadded);
                    }

                    if (count($recentlyadded) == $section->item_limit) {
                        break;
                        exit(1);
                    }
                }
                if (count($recent_data) == 0) {
                    $recentlyadded = [];
                }
                foreach ($recent_data as $key => $item) {
                    $d = \Request::getHost();
                    $domain = str_replace('www.', '', $d);
                    if (strstr($domain, 'localhost')) {
                        $ipaddress = '43.251.92.73';
                    } else {
                        $ipaddress = $request->getClientIp();
                        $ipaddress = $ipaddress == '::1' ? '43.251.92.73' : $ipaddress;
                    }
                    $geoip = geoip()->getLocation($ipaddress);
                    $usercountry = strtoupper($geoip->country);

                    $rectvs = App\TvSeries::join('seasons', 'seasons.tv_series_id', '=', 'tv_series.id')
                        ->join('episodes', 'episodes.seasons_id', '=', 'seasons.id')
                        ->join('videolinks', 'videolinks.episode_id', '=', 'episodes.id')
                        ->select(
                            'seasons.id as seasonid',
                            'tv_series.genre_id as genre_id',
                            'tv_series.id as id',
                            'tv_series.type as type',
                            'tv_series.status as status',
                            'tv_series.thumbnail as thumbnail',
                            'tv_series.title as title',
                            'tv_series.rating as rating',
                            'seasons.publish_year as publish_year',
                            'tv_series.maturity_rating as age_req',
                            'tv_series.detail as detail',
                            'seasons.season_no as season_no',
                            'videolinks.iframeurl as iframeurl',
                            'seasons.season_slug as season_slug',
                            'seasons.trailer_url as trailer_url',
                            'seasons.tmdb as tmdb',
                            'tv_series.is_custom_label as is_custom_label',
                            'tv_series.label_id as label_id',
                        )
                        ->where('tv_series.country', 'NOT like', '%' . $usercountry . '%')
                        ->where('tv_series.id', $item->tv_series_id)
                        ->first();

                    $recentlyadded[] = $rectvs;

                    if ($section->order == 1) {
                        arsort($recentlyadded);
                    }

                    if (count($recentlyadded) == $section->item_limit) {
                        break;
                        exit(1);
                    }
                }

                $recentlyadded = array_values(array_filter($recentlyadded));
                //     echo "<pre>";
                // print_r(count($recentlyadded));
                // echo "</pre>";
            @endphp

            @if ($section->section_id == 1 && $recentlyadded != null && count($recentlyadded) > 0)
                <div class="container my-5">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-6 d-flex align-items-center gap-2">
                                    <h4 class="first-sider-heading">{{ __('Recently AddedIn') }}</h4>

                                    @if ($auth && getSubscription()->getData()->subscribed == true)
                                        <a href="{{ route('showall', ['menuid' => $menu->id, 'menuname' => $menu->name]) }}"
                                            class="see-more view-all-images text-decoration-none ms-3 border">
                                            <b>{{ __('View All') }}</b></a>
                                    @else
                                        <a href="{{ route('guestshowall', ['menuid' => $menu->id, 'menuname' => $menu->name]) }}"
                                            class="see-more view-all-images text-decoration-none ms-3 border">
                                            <b>{{ __('View All') }}</b></a>
                                    @endif


                                </div>
                            </div>
                        </div>



                        <!-- Recently added movies and tv shows in list view End-->
                        @if ($section->view == 1 || $section->view == 0)
                            <div class="col-12">
                                <div class="home-demo position-relative">
                                    <div class="owl-carousel owl-theme">
                                        @foreach ($recentlyadded as $item)
                                            @php
                                                if (isset($auth) && $auth != null) {
                                                    if ($item->type == 'M') {
                                                        $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                                            'wishlists',
                                                        )
                                                            ->where([
                                                                ['user_id', '=', $auth->id],
                                                                ['movie_id', '=', $item->id],
                                                            ])
                                                            ->first();
                                                    }
                                                }

                                                if (isset($auth) && $auth != null) {
                                                    $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();

                                                    if (isset($gets1)) {
                                                        $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                                            'wishlists',
                                                        )
                                                            ->where([
                                                                ['user_id', '=', $auth->id],
                                                                ['season_id', '=', $gets1->id],
                                                            ])
                                                            ->first();
                                                    }
                                                } else {
                                                    $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();
                                                }
                                            @endphp

                                            @if ($item->status == 1)
                                                @if ($item->type == 'M')
                                                    @php
                                                        if ($item->thumbnail != null) {
                                                            $image =
                                                                public_path() .
                                                                '/images/movies/thumbnails/' .
                                                                $item->thumbnail;
                                                        } else {
                                                            $image = Avatar::create($item->title)->toBase64();
                                                        }

                                                        // Read image path, convert to base64 encoding

                                                        $imageData = base64_encode(@file_get_contents($image));
                                                        if ($imageData) {
                                                            $src =
                                                                'data: ' .
                                                                mime_content_type($image) .
                                                                ';base64,' .
                                                                $imageData;
                                                        } else {
                                                            $src = Avatar::create($item->title)->toBase64();
                                                        }
                                                    @endphp
                                                    @if (hidedata($item->id, $item->type) != 1)
                                                        {{--Working   --}}
                                                        @if ($auth && getSubscription()->getData()->subscribed == true)
                                                          @include('partials.auth_view');
                                                        @else
                                                          @include('partials.guest_view');
                                                        @endif
                                                        
                                                    @endif
                                                    {{-- Tv Series start --}}
                                                @elseif($item->type == 'T')
                                                    @php
                                                        $image = 'images/tvseries/thumbnails/' . $item->thumbnail;
                                                        // Read image path, convert to base64 encoding

                                                        $imageData = base64_encode(@file_get_contents($image));
                                                        if ($imageData) {
                                                            // Format the image SRC:  data:{mime};base64,{data};
                                                            $src =
                                                                'data: ' .
                                                                mime_content_type($image) .
                                                                ';base64,' .
                                                                $imageData;
                                                        } else {
                                                            $src = Avatar::create($item->title)->toBase64();
                                                        }
                                                    @endphp



                                                    {{-- T --}}
                                                    @if (hidedata($gets1->id, $gets1->type) != 1)

                                                      @if ($auth && getSubscription()->getData()->subscribed == true)
                                                        @include('partials.auth_view_webseries');
                                                      @else
                                                        @include('partials.guest_view_webseries');
                                                      @endif

                                                      
                                                    @endif
                                                    {{--  T --}}

                                                    {{-- old   --}}
                                                    {{-- @if (hidedata($gets1->id, $gets1->type) != 1)
                                                        <div class="genre-prime-slide">
                                                            <div class="genre-slide-image home-prime-slider protip"
                                                                data-pt-placement="outside"
                                                                data-pt-title="#prime-mix-description-block{{ $item->id }}{{ $item->type }}">
                                                                @if ($auth && getSubscription()->getData()->subscribed == true)
                                                                    <a
                                                                        @if (isset($gets1)) href="{{ url('show/detail', $gets1->season_slug) }}" @endif>
                                                                        @if ($src)
                                                                            <img data-src="{{ $src }}"
                                                                                class="img-responsive owl-lazy"
                                                                                alt="genre-image">
                                                                        @endif
                                                                    </a>
                                                                    <div class="hide-icon">
                                                                        <a onclick="hideforme('{{ $gets1->id }}','{{ $gets1->type }}')"
                                                                            title="{{ __('Hide this Movie') }}"
                                                                            class=""><i
                                                                                class="fa fa-eye-slash"></i></a>
                                                                    </div>
                                                                @else
                                                                    <a
                                                                        @if (isset($gets1)) href="{{ url('show/guest/detail', $gets1->season_slug) }}" @endif>
                                                                        @if ($src)
                                                                            <img data-src="{{ $src }}"
                                                                                class="img-responsive owl-lazy"
                                                                                alt="genre-image">
                                                                        @endif
                                                                    </a>
                                                                @endif
                                                                @if ($item->is_custom_label == 1)
                                                                    @if (isset($item->label_id))
                                                                        <span
                                                                            class="badge bg-info">{{ $item->label->name }}</span>
                                                                    @endif
                                                                @endif

                                                            </div>
                                                            @if (isset($protip) && $protip == 1)
                                                                <div id="prime-mix-description-block{{ $item->id }}{{ $item->type }}"
                                                                    class="prime-description-block">
                                                                    <h5 class="description-heading">
                                                                        {{ $item->title }}
                                                                    </h5>

                                                                    <ul class="description-list">
                                                                        <li>{{ __('Tmdb Rating') }}
                                                                            {{ $item->rating }}
                                                                        </li>
                                                                        <li>{{ __('Season') }}
                                                                            {{ $item->season_no }}
                                                                        </li>
                                                                        <li>{{ $item->publish_year }}</li>
                                                                        <li>{{ $item->age_req }}</li>

                                                                    </ul>
                                                                    <div class="main-des">
                                                                        @if ($item->detail != null || $item->detail != '')
                                                                            <p>{{ str_limit($item->detail, 100, '...') }}
                                                                            </p>
                                                                        @else
                                                                            <p>{{ str_limit($item->detail, 100, '...') }}
                                                                            </p>
                                                                        @endif
                                                                        @if ($auth && getSubscription()->getData()->subscribed == true)
                                                                            <a
                                                                                href="{{ url('show/detail', $item->season_slug) }}">{{ __('Read More') }}</a>
                                                                        @else
                                                                            <a
                                                                                href="{{ url('show/guest/detail', $item->season_slug) }}">{{ __('Read More') }}</a>
                                                                        @endif
                                                                    </div>

                                                                    <div class="des-btn-block">
                                                                        @if ($auth && getSubscription()->getData()->subscribed == true)
                                                                            @if (isset($gets1->episodes[0]) && checkInTvseries($item) == true && isset($gets1->episodes[0]->video_link))
                                                                                @if ($item->age_req == 'all age' || $age >= str_replace('+', '', $item->age_req))
                                                                                    @if ($gets1->episodes[0]->video_link['iframeurl'] != '')
                                                                                        <a href="#"
                                                                                            onclick="playoniframe('{{ $gets1->episodes[0]->video_link['iframeurl'] }}','{{ $gets1->episodes[0]->seasons->tvseries->id }}','tv')"
                                                                                            class="btn btn-play"><span
                                                                                                class= "play-btn-icon"><i
                                                                                                    class="fa fa-play"></i></span>
                                                                                            <span
                                                                                                class="play-text">{{ __('Play Now') }}</span>
                                                                                        </a>
                                                                                    @else
                                                                                        <a href="{{ route('watchTvShow', $gets1->id) }}"
                                                                                            class="iframe btn btn-play"><span
                                                                                                class="play-btn-icon"><i
                                                                                                    class="fa fa-play"></i></span>
                                                                                            <span
                                                                                                class="play-text">{{ __('Play Now') }}</span></a>
                                                                                    @endif
                                                                                @else
                                                                                    <a onclick="myage({{ $age }})"
                                                                                        class=" btn btn-play"><span
                                                                                            class="play-btn-icon"><i
                                                                                                class="fa fa-play"></i></span>
                                                                                        <span
                                                                                            class="play-text">{{ __('Play Now') }}</span></a>
                                                                                @endif
                                                                            @endif
                                                                            @if ($gets1->trailer_url != null || $gets1->trailer_url != '')
                                                                                <a href="{{ route('watchtvTrailer', $gets1->id) }}"
                                                                                    class="iframe btn btn-default">{{ __('Watch Trailer') }}</a>
                                                                            @endif
                                                                        @else
                                                                            @if ($gets1->trailer_url != null || $gets1->trailer_url != '')
                                                                                <a href="{{ route('guestwatchtvtrailer', $gets1->id) }}"
                                                                                    class="iframe btn btn-default">{{ __('Watch Trailer') }}</a>
                                                                            @endif
                                                                        @endif

                                                                        @if ($catlog == 0 && getSubscription()->getData()->subscribed == true)
                                                                            @if (isset($gets1))
                                                                                @if (isset($wishlist_check->added))
                                                                                    <a onclick="addWish({{ $gets1->id }},'{{ $gets1->type }}')"
                                                                                        class="addwishlistbtn{{ $gets1->id }}{{ $gets1->type }} btn-default">{{ $wishlist_check->added == 1 ? __('Remove From Watchlist') : __('Add to Watchlist') }}</a>
                                                                                @else
                                                                                    @if ($gets1)
                                                                                        <a onclick="addWish({{ $gets1->id }},'{{ $gets1->type }}')"
                                                                                            class="addwishlistbtn{{ $gets1->id }}{{ $gets1->type }} btn-default">{{ __('Add to Watchlist') }}
                                                                                        </a>
                                                                                    @endif
                                                                                @endif
                                                                            @endif
                                                                        @elseif($catlog == 1 && $auth)
                                                                            @if (isset($gets1))
                                                                                @if (isset($wishlist_check->added))
                                                                                    <a onclick="addWish({{ $gets1->id }},'{{ $gets1->type }}')"
                                                                                        class="addwishlistbtn{{ $gets1->id }}{{ $gets1->type }} btn-default">{{ $wishlist_check->added == 1 ? __('Remove From Watchlist') : __('Add to Watchlist') }}</a>
                                                                                @else
                                                                                    @if ($gets1)
                                                                                        <a onclick="addWish({{ $gets1->id }},'{{ $gets1->type }}')"
                                                                                            class="addwishlistbtn{{ $gets1->id }}{{ $gets1->type }} btn-default">{{ __('add t owatchlist') }}
                                                                                        </a>
                                                                                    @endif
                                                                                @endif
                                                                            @endif
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                            @endif
                                                        </div>
                                                    @endif --}}
                                                    {{-- old --}}
                                                @endif

                                                {{-- Tv serices end --}}
                                            @endif
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        @endif
                        <!-- Recently added movies and tv shows in list view End-->
                        <!-- Recently Tvshows and movies in Grid view -->
                        @if ($section->view == 0)
                            {{-- This is Pending --}}
                        @endif
                        <!-- Recently Tvshows and movies in Grid view END-->


                    </div>
                </div>
            @endif
        @endforeach
        {{-- 1111 --}}



        {{-- Featured Start --}}
          
         <!-- Featured Movies and TvShows -->   
  @foreach($menu->menusections as $section)
        
  
  @php
      $featuresitems = [];
      
      
      foreach ($menu_data as $key => $item) {

        $d = \Request::getHost();
      $domain = str_replace("www.", "", $d);
      if (strstr($domain, 'localhost') ) {
        $ipaddress='43.251.92.73'; 
      }else{
        $ipaddress = $request->getClientIp();
        $ipaddress = ($ipaddress == "::1") ? "43.251.92.73" : $ipaddress; 
      }
      $geoip = geoip()->getLocation($ipaddress);
      $usercountry = strtoupper($geoip->country);
          
          $fmovie =  App\Movie::join('videolinks','videolinks.movie_id','=','movies.id')
                       ->select('movies.id as id','movies.title as title','movies.type as type','movies.status as status','movies.genre_id as genre_id','movies.thumbnail as thumbnail','movies.rating as rating','movies.duration as duration','movies.publish_year as publish_year','movies.maturity_rating as maturity_rating','movies.detail as detail','movies.trailer_url as trailer_url','movies.slug as slug','movies.tmdb as tmdb','movies.is_custom_label as is_custom_label','movies.label_id as label_id')
                        ->where('movies.is_upcoming','!=' ,1)
                        ->where('movies.is_kids','!=' ,1)
                        ->where('movies.country', 'NOT like', '%'.$usercountry.'%')
                       ->where('movies.id',$item->movie_id)->where('movies.featured', '1')->first();
            
          if($fmovie != NULL){
            $featuresitems[] = $fmovie;
          }
           

          if($section->order == 1){
            arsort($featuresitems);
          }

          if(count($featuresitems) == $section->item_limit){
              break;
              exit();
          }


      }
    

   
      
      foreach ($menu_data as $key => $item) {
        
        $d = \Request::getHost();
      $domain = str_replace("www.", "", $d);
      if (strstr($domain, 'localhost') ) {
        $ipaddress='43.251.92.73'; 
      }else{
        $ipaddress = $request->getClientIp();
        $ipaddress = ($ipaddress == "::1") ? "43.251.92.73" : $ipaddress; 
      }
      $geoip = geoip()->getLocation($ipaddress);
      $usercountry = strtoupper($geoip->country);
      
         $ftvs = App\TvSeries::
                        join('seasons','seasons.tv_series_id','=','tv_series.id')
                        ->join('episodes','episodes.seasons_id','=','seasons.id')
                        ->join('videolinks','videolinks.episode_id','=','episodes.id')
                        ->select('seasons.id as seasonid','tv_series.genre_id as genre_id','tv_series.id as id','tv_series.type as type','tv_series.status as status','tv_series.thumbnail as thumbnail','tv_series.title as title','tv_series.rating as rating','seasons.publish_year as publish_year','tv_series.maturity_rating as age_req','tv_series.detail as detail','seasons.season_no as season_no','videolinks.iframeurl as iframeurl','seasons.season_slug as season_slug','seasons.trailer_url as trailer_url','seasons.tmdb as tmdb','tv_series.is_custom_label as is_custom_label','tv_series.label_id as label_id')
                        ->where('tv_series.is_kids','!=' ,1)
                        ->where('tv_series.country', 'NOT like', '%'.$usercountry.'%')
                        ->where('tv_series.id',$item->tv_series_id)->where('tv_series.featured','1')->first();

          if($ftvs != NULL){
            $featuresitems[] = $ftvs;
          }
          

          if($section->order == 1){
            arsort($featuresitems);
          }
          
          if(count($featuresitems) == $section->item_limit+1){
              break;
              exit();
          }

      }
    

      $featuresitems = array_values(array_filter($featuresitems));
      
  @endphp



  
  @if($section->section_id == 3 && $featuresitems != NULL && count($featuresitems)>0)
  <div class="container my-5">
      <div class="row">
          <div class="col-12">
              <div class="row">
                  <div class="col-6 d-flex align-items-center gap-2">
                      <h4 class="first-sider-heading">{{__('Featured In')}} </h4>
{{-- 
                      @if ($auth && getSubscription()->getData()->subscribed == true)
                          <a href="{{ route('showall', ['menuid' => $menu->id, 'menuname' => $menu->name]) }}"
                              class="see-more view-all-images text-decoration-none ms-3 border">
                              <b>{{ __('View All') }}</b></a>
                      @else
                          <a href="{{ route('guestshowall', ['menuid' => $menu->id, 'menuname' => $menu->name]) }}"
                              class="see-more view-all-images text-decoration-none ms-3 border">
                              <b>{{ __('View All') }}</b></a>
                      @endif --}}


                  </div>
              </div>
          </div>



          <!-- Recently added movies and tv shows in list view End-->
          @if ($section->view == 1 || $section->view == 0)
              <div class="col-12">
                  <div class="home-demo position-relative">
                      <div class="owl-carousel owl-theme">
                          @foreach ($featuresitems as $item)
                              @php
                                  if (isset($auth) && $auth != null) {
                                      if ($item->type == 'M') {
                                          $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                              'wishlists',
                                          )
                                              ->where([
                                                  ['user_id', '=', $auth->id],
                                                  ['movie_id', '=', $item->id],
                                              ])
                                              ->first();
                                      }
                                  }

                                  if (isset($auth) && $auth != null) {
                                      $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();

                                      if (isset($gets1)) {
                                          $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                              'wishlists',
                                          )
                                              ->where([
                                                  ['user_id', '=', $auth->id],
                                                  ['season_id', '=', $gets1->id],
                                              ])
                                              ->first();
                                      }
                                  } else {
                                      $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();
                                  }
                              @endphp

                              @if ($item->status == 1)
                                  @if ($item->type == 'M')
                                      @php
                                          if ($item->thumbnail != null) {
                                              $image =
                                                  public_path() .
                                                  '/images/movies/thumbnails/' .
                                                  $item->thumbnail;
                                          } else {
                                              $image = Avatar::create($item->title)->toBase64();
                                          }

                                          // Read image path, convert to base64 encoding

                                          $imageData = base64_encode(@file_get_contents($image));
                                          if ($imageData) {
                                              $src =
                                                  'data: ' .
                                                  mime_content_type($image) .
                                                  ';base64,' .
                                                  $imageData;
                                          } else {
                                              $src = Avatar::create($item->title)->toBase64();
                                          }
                                      @endphp
                                      @if (hidedata($item->id, $item->type) != 1)
                                          {{--Working   --}}
                                          @if ($auth && getSubscription()->getData()->subscribed == true)
                                            @include('partials.auth_view');
                                          @else
                                            @include('partials.guest_view');
                                          @endif
                                          
                                      @endif
                                      {{-- Tv Series start --}}
                                  @elseif($item->type == 'T')
                                      @php
                                          $image = 'images/tvseries/thumbnails/' . $item->thumbnail;
                                          // Read image path, convert to base64 encoding

                                          $imageData = base64_encode(@file_get_contents($image));
                                          if ($imageData) {
                                              // Format the image SRC:  data:{mime};base64,{data};
                                              $src =
                                                  'data: ' .
                                                  mime_content_type($image) .
                                                  ';base64,' .
                                                  $imageData;
                                          } else {
                                              $src = Avatar::create($item->title)->toBase64();
                                          }
                                      @endphp



                                      {{-- T --}}
                                      @if (hidedata($gets1->id, $gets1->type) != 1)

                                        @if ($auth && getSubscription()->getData()->subscribed == true)
                                          @include('partials.auth_view_webseries');
                                        @else
                                          @include('partials.guest_view_webseries');
                                        @endif

                                        
                                      @endif
                                      
                                  @endif

                                  {{-- Tv serices end --}}
                              @endif
                          @endforeach
                      </div>
                  </div>
              </div>
          @endif
          <!-- Recently added movies and tv shows in list view End-->
          <!-- Recently Tvshows and movies in Grid view -->
          @if ($section->view == 0)
              {{-- This is Pending --}}
          @endif
          <!-- Recently Tvshows and movies in Grid view END-->


      </div>
  </div>
@endif

@endforeach
 <!-- Featured Tv Shows and Movies end-->

        {{-- Featured End --}}



       {{-- because you watched Start --}}
          
       @if(Auth::user() && $auth != NULL && getSubscription()->getData()->subscribed == true)

       @foreach($menu->menusections as $section)
           @php
            
             $watchistory_last_movie=App\WatchHistory::where('user_id',$auth->id)->orderBy('id','DESC')->where('movie_id','!=',NULL)->take(5)->get();
 
             $watchistory_last_tv=App\WatchHistory::where('user_id',$auth->id)->orderBy('id','DESC')->where('tv_id','!=',NULL)->take(5)->get();
 
             $customGenreMovie = [];
             $customGenreTv = [];
             
             foreach ($watchistory_last_movie as $key => $w) {
                $movie_find_last = App\Movie::where('id','=',$w->movie_id)->where('is_kids',0)->first();
                
                if(isset($movie_find_last)){
                 $customGenreMovie[] = $movie_find_last->genre_id;
                }
             }
 
             foreach ($watchistory_last_tv as $key => $k) {
                $tv_show = App\TvSeries::where('id','=',$k->tv_id)->where('is_kids',0)->first();
                if(isset($tv_show)){
                 $customGenreTv[] = $tv_show->genre_id;
                }
             }
            
 
          
 
           $customGenreMovie =  array_unique($customGenreMovie);
           $customGenreTv =  array_unique($customGenreTv);
 
          
           
           $recom_block = collect();
 
           $customGenreMovie =  array_unique($customGenreMovie);
           $customGenreTv =  array_unique($customGenreTv);
 
          
          
           //Getting Recommnaded Movies based on genre
 
 
           foreach ($customGenreMovie as $key => $g) {
             $x = App\Movie::orderBy('id','DESC')->where('is_kids',0)->where('genre_id', $g )->take(50)->get();
              $recom_block->push($x);
              
           }
          
           //Getting Recommnaded Tv Series based on genre
            foreach ($customGenreTv as $key => $g) {
              $y =App\TvSeries::orderBy('id','DESC')->where('is_kids',0)->where('genre_id', $g )->take(50)->get();
              $recom_block->push($y);
           }
 
           
           $recom_block = $recom_block->flatten();
 
               
           @endphp
            
           @if($section->section_id == 4 && $recom_block != NULL && count($recom_block)>0)
           <div class="container my-5">
               <div class="row">
                   <div class="col-12">
                       <div class="row">
                           <div class="col-6 d-flex align-items-center gap-2">

                            @php
                            $watch = App\WatchHistory::OrderBy('id','DESC')->first();
                            
                            $movie = App\Movie::where('id',$watch->movie_id)->first();
                            $tv = App\TvSeries::where('id',$watch->tv_id)->first();
                            @endphp
                            @if(isset($movie))
                           
                             <h4 class="first-sider-heading">{{__('Because you watched')}}: {{isset($movie->title) ? ucfirst($movie->title) : ''}}</h4>
                             @else
                             <h4 class="first-sider-heading">{{__('Because you watched')}} : {{isset($tv->title) ? ucfirst($tv->title) : ''}}</h4>
 
                           @endif

                               
   
                               {{-- @if ($auth && getSubscription()->getData()->subscribed == true)
                                   <a href="{{ route('showall', ['menuid' => $menu->id, 'menuname' => $menu->name]) }}"
                                       class="see-more view-all-images text-decoration-none ms-3 border">
                                       <b>{{ __('View All') }}</b></a>
                               @else
                                   <a href="{{ route('guestshowall', ['menuid' => $menu->id, 'menuname' => $menu->name]) }}"
                                       class="see-more view-all-images text-decoration-none ms-3 border">
                                       <b>{{ __('View All') }}</b></a>
                               @endif --}}
   
   
                           </div>
                       </div>
                   </div>
   
   
   
                   <!-- Recently added movies and tv shows in list view End-->
                   @if ($section->view == 1 || $section->view == 0)
                       <div class="col-12">
                           <div class="home-demo position-relative">
                               <div class="owl-carousel owl-theme">
                                   @foreach ($recom_block as $item)
                                       @php
                                           if (isset($auth) && $auth != null) {
                                               if ($item->type == 'M') {
                                                   $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                                       'wishlists',
                                                   )
                                                       ->where([
                                                           ['user_id', '=', $auth->id],
                                                           ['movie_id', '=', $item->id],
                                                       ])
                                                       ->first();
                                               }
                                           }
   
                                           if (isset($auth) && $auth != null) {
                                               $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();
   
                                               if (isset($gets1)) {
                                                   $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                                       'wishlists',
                                                   )
                                                       ->where([
                                                           ['user_id', '=', $auth->id],
                                                           ['season_id', '=', $gets1->id],
                                                       ])
                                                       ->first();
                                               }
                                           } else {
                                               $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();
                                           }
                                       @endphp
   
                                       @if ($item->status == 1)
                                           @if ($item->type == 'M')
                                               @php
                                                   if ($item->thumbnail != null) {
                                                       $image =
                                                           public_path() .
                                                           '/images/movies/thumbnails/' .
                                                           $item->thumbnail;
                                                   } else {
                                                       $image = Avatar::create($item->title)->toBase64();
                                                   }
   
                                                   // Read image path, convert to base64 encoding
   
                                                   $imageData = base64_encode(@file_get_contents($image));
                                                   if ($imageData) {
                                                       $src =
                                                           'data: ' .
                                                           mime_content_type($image) .
                                                           ';base64,' .
                                                           $imageData;
                                                   } else {
                                                       $src = Avatar::create($item->title)->toBase64();
                                                   }
                                               @endphp
                                               @if (hidedata($item->id, $item->type) != 1)
                                                   {{--Working   --}}
                                                   @if ($auth && getSubscription()->getData()->subscribed == true)
                                                     @include('partials.auth_view');
                                                   @else
                                                     @include('partials.guest_view');
                                                   @endif
                                                   
                                               @endif
                                               {{-- Tv Series start --}}
                                           @elseif($item->type == 'T')
                                               @php
                                                   $image = 'images/tvseries/thumbnails/' . $item->thumbnail;
                                                   // Read image path, convert to base64 encoding
   
                                                   $imageData = base64_encode(@file_get_contents($image));
                                                   if ($imageData) {
                                                       // Format the image SRC:  data:{mime};base64,{data};
                                                       $src =
                                                           'data: ' .
                                                           mime_content_type($image) .
                                                           ';base64,' .
                                                           $imageData;
                                                   } else {
                                                       $src = Avatar::create($item->title)->toBase64();
                                                   }
                                               @endphp
   
   
   
                                               {{-- T --}}
                                               @if (hidedata($gets1->id, $gets1->type) != 1)
   
                                                 @if ($auth && getSubscription()->getData()->subscribed == true)
                                                   @include('partials.auth_view_webseries');
                                                 @else
                                                   @include('partials.guest_view_webseries');
                                                 @endif
   
                                                 
                                               @endif
                                              
                                           @endif
   
                                           {{-- Tv serices end --}}
                                       @endif
                                   @endforeach
                               </div>
                           </div>
                       </div>
                   @endif
                   <!-- Recently added movies and tv shows in list view End-->
                   <!-- Recently Tvshows and movies in Grid view -->
                   @if ($section->view == 0)
                       {{-- This is Pending --}}
                   @endif
                   <!-- Recently Tvshows and movies in Grid view END-->
   
   
               </div>
           </div>
       @endif
   @endforeach
   @endif
       
       {{--because you watched End --}}



       
    {{-- Continue watch start  --}}
    @if(Auth::user() && getSubscription()->getData()->subscribed == true)
    @foreach($menu->menusections as $section)
    @php
        $historyadded = [];
       
        foreach ($watchistory as $key => $item) {
          
            $rm =  App\Movie::
                        join('watch_histories','movies.id','=','watch_histories.movie_id')
                        ->join('menu_videos','menu_videos.movie_id','=','movies.id')
                        ->join('videolinks','videolinks.movie_id','=','movies.id')
                         ->select('movies.id as id','watch_histories.movie_id as movie_id','movies.title as title','movies.rating as rating','movies.duration as duration','movies.publish_year as publish_year','movies.maturity_rating as maturity_rating','movies.detail as detail','movies.trailer_url as trailer_url','videolinks.iframeurl as iframeurl','movies.status as status','movies.type as type','movies.thumbnail as thumbnail','movies.slug as slug','movies.tmdb as tmdb','movies.is_custom_label as is_custom_label','movies.label_id as label_id')
                          ->where('movies.is_upcoming','!=' ,1)
                         ->where('watch_histories.id',$item->id)->where('menu_videos.menu_id',$menu->id)->first();
              
            $historyadded[] = $rm;

            
            if($section->order == 1){
              arsort($historyadded);
            }
           

            if(count($historyadded) == $section->item_limit){
                break;
                exit(1);
            }
        }
       

        foreach ($watchistory as $key => $item) {
            
            $rectvs =  App\TvSeries::
                          join('watch_histories','tv_series.id','=','watch_histories.tv_id')
                             ->join('seasons','seasons.tv_series_id','=','tv_series.id')
                          ->join('episodes','episodes.seasons_id','=','seasons.id')
                          ->join('videolinks','videolinks.episode_id','=','episodes.id')
                         ->join('menu_videos','menu_videos.tv_series_id','=','tv_series.id')
                          ->select('seasons.id as seasonid','tv_series.genre_id as genre_id','tv_series.id as id','tv_series.type as type','tv_series.status as status','tv_series.thumbnail as thumbnail','tv_series.title as title','tv_series.rating as rating','seasons.publish_year as publish_year','tv_series.maturity_rating as age_req','tv_series.detail as detail','seasons.season_no as season_no','videolinks.iframeurl as iframeurl','seasons.tmdb as tmdb','tv_series.is_custom_label as is_custom_label','tv_series.label_id as label_id')
                          ->where('watch_histories.id',$item->id)->where('menu_videos.menu_id',$menu->id)->first();
              
            $historyadded[] = $rectvs;
          

            if($section->order == 1){
              arsort($historyadded);
            }
            
            if(count($historyadded) == $section->item_limit){
                break;
                exit(1);
            }

        }
        
        

        $historyadded = array_values(array_filter($historyadded));
        
    @endphp

@if($section->section_id == 5 && $historyadded != NULL && count($historyadded) >0)
        <div class="container my-5">
            <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-6 d-flex align-items-center gap-2">
                            <h4 class="first-sider-heading">{{__('Continue Watching For')}} {{Auth::user()->name}}</h4>

                            {{-- @if ($auth && getSubscription()->getData()->subscribed == true)
                                <a href="{{ route('showall', ['menuid' => $menu->id, 'menuname' => $menu->name]) }}"
                                    class="see-more view-all-images text-decoration-none ms-3 border">
                                    <b>{{ __('View All') }}</b></a>
                            @else
                                <a href="{{ route('guestshowall', ['menuid' => $menu->id, 'menuname' => $menu->name]) }}"
                                    class="see-more view-all-images text-decoration-none ms-3 border">
                                    <b>{{ __('View All') }}</b></a>
                            @endif --}}


                        </div>
                    </div>
                </div>



                <!-- Recently added movies and tv shows in list view End-->
                @if ($section->view == 1 || $section->view == 0)
                    <div class="col-12">
                        <div class="home-demo position-relative">
                            <div class="owl-carousel owl-theme">
                                @foreach ($historyadded as $item)
                                    @php
                                        if (isset($auth) && $auth != null) {
                                            if ($item->type == 'M') {
                                                $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                                    'wishlists',
                                                )
                                                    ->where([
                                                        ['user_id', '=', $auth->id],
                                                        ['movie_id', '=', $item->id],
                                                    ])
                                                    ->first();
                                            }
                                        }

                                        if (isset($auth) && $auth != null) {
                                            $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();

                                            if (isset($gets1)) {
                                                $wishlist_check = \Illuminate\Support\Facades\DB::table(
                                                    'wishlists',
                                                )
                                                    ->where([
                                                        ['user_id', '=', $auth->id],
                                                        ['season_id', '=', $gets1->id],
                                                    ])
                                                    ->first();
                                            }
                                        } else {
                                            $gets1 = App\Season::where('tv_series_id', '=', $item->id)->first();
                                        }
                                    @endphp

                                    @if ($item->status == 1)
                                        @if ($item->type == 'M')
                                            @php
                                                if ($item->thumbnail != null) {
                                                    $image =
                                                        public_path() .
                                                        '/images/movies/thumbnails/' .
                                                        $item->thumbnail;
                                                } else {
                                                    $image = Avatar::create($item->title)->toBase64();
                                                }

                                                // Read image path, convert to base64 encoding

                                                $imageData = base64_encode(@file_get_contents($image));
                                                if ($imageData) {
                                                    $src =
                                                        'data: ' .
                                                        mime_content_type($image) .
                                                        ';base64,' .
                                                        $imageData;
                                                } else {
                                                    $src = Avatar::create($item->title)->toBase64();
                                                }
                                            @endphp
                                            @if (hidedata($item->id, $item->type) != 1)
                                                {{--Working   --}}
                                                @if ($auth && getSubscription()->getData()->subscribed == true)
                                                  @include('partials.auth_view');
                                                @else
                                                  @include('partials.guest_view');
                                                @endif
                                                
                                            @endif
                                            {{-- Tv Series start --}}
                                        @elseif($item->type == 'T')
                                            @php
                                                $image = 'images/tvseries/thumbnails/' . $item->thumbnail;
                                                // Read image path, convert to base64 encoding

                                                $imageData = base64_encode(@file_get_contents($image));
                                                if ($imageData) {
                                                    // Format the image SRC:  data:{mime};base64,{data};
                                                    $src =
                                                        'data: ' .
                                                        mime_content_type($image) .
                                                        ';base64,' .
                                                        $imageData;
                                                } else {
                                                    $src = Avatar::create($item->title)->toBase64();
                                                }
                                            @endphp



                                            {{-- T --}}
                                            @if (hidedata($gets1->id, $gets1->type) != 1)

                                              @if ($auth && getSubscription()->getData()->subscribed == true)
                                                @include('partials.auth_view_webseries');
                                              @else
                                                @include('partials.guest_view_webseries');
                                              @endif

                                              
                                            @endif
                                           
                                        @endif

                                        {{-- Tv serices end --}}
                                    @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                @endif
                <!-- Recently added movies and tv shows in list view End-->
                <!-- Recently Tvshows and movies in Grid view -->
                @if ($section->view == 0)
                    {{-- This is Pending --}}
                @endif
                <!-- Recently Tvshows and movies in Grid view END-->


            </div>
        </div>
    @endif
@endforeach
@endif
    {{-- Continue watch end  --}}



        {{-- View all General Start --}}

        @foreach ($menu->menusections as $section)
            @if ($section->section_id == 2)
                @if (count($menu->menugenreshow) > 0)
                    
                     @include('partials.selectgenre') 
                @endif


                
                   <!--View All Genre slider start -->
                        <div class="container my-5">
                          <div class="row">
                            <div class="col-12">
                              <div class="row">
                                <div class="col-6 d-flex align-items-center gap-2">
                                  <h4 class="first-sider-heading">{{ __('View All genre') }}</h4>
                                  <a
                                    href="#"
                                    class="view-all-images text-decoration-none ms-3 border"
                                    >View all</a
                                  >
                                </div>
                              </div>
                            </div>
                            @if (count($getallgenre) > 0)
                              <div class="col-12">
                                <div class="home-demo">
                                  <div class="owl-carousel owl-theme">
                                  
                                    {{-- loop start --}}
                                    @foreach ($getallgenre as $genre)
                                      
                                        @if ($auth && getSubscription()->getData()->subscribed == true)
                                        
                                        @include('partials.auth_user_genre');
                                        
                                        
                                        @else
                                        
                                        @include('partials.guest_user_genre');
                                        
                                        @endif

                                    
                                      @endforeach
                                    {{-- Loop end --}}
                                
                                  </div>
                                </div>
                              </div>
                            @endif
                          </div>
                        </div>
              <!-- View All Genre slider end -->


                
            @endif
        @endforeach
        {{-- View all general end --}}
    @endif



    {{--  --}}


    <!-- footer start -->
    @include('partials.footer')
    <!-- footer end -->
    {{-- @endsection --}}
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.1/js/swiper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            // Swiper: Slider
            new Swiper('.swiper-container', {
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
                spaceBetween: 20,
                centeredSlides: true,
                loop: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                breakpoints: {
                    1920: {
                        slidesPerView: 1.5,
                        spaceBetween: 30
                    },
                    580: {
                        slidesPerView: 1,
                        spaceBetween: 10
                    },
                    1200: {
                        slidesPerView: 1.5,
                        spaceBetween: 10
                    }
                }
            });
        });




        $(function() {
            // Owl Carousel
            var owl = $(".owl-carousel");
            owl.owlCarousel({
                items: 5,
                margin: 10,
                loop: false,
                nav: true,
                dots: false,
                responsive: {
                    0: {
                        items: 1.5
                    },
                    600: {
                        items: 3
                    },
                    1000: {
                        items: 3
                    },
                    1200: {
                        items: 5
                    },

                }
            });
        });
    </script>
</body>

</html>
