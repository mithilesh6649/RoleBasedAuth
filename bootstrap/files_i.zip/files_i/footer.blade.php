<footer class="footer footer-styling">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-4 mt-4 col-lg-3 text-center text-sm-start">
                <div class="information">
                    <img src="{{ asset('assets_new/img/QaumTV-logo-trans 1.png') }}" alt="logo" />
                </div>
            </div>
            <div class="col-sm-6 col-md-4 mt-4 col-lg-3 text-center text-sm-start">
                <div class="Corporate">
                    <h6 class="footer-heading text-white mb-0">Corporate</h6>
                    <ul class="list-unstyled footer-link mt-3">
                        <li class="mb-1">
                            <a href="#" class="text-decoration-none li-footer">Term and conditions</a>
                        </li>
                        <li class="mb-1">
                            <a href="#" class="text-decoration-none li-footer">Privacy Policy</a>
                        </li>
                        <li class="mb-1">
                            <a href="#" class="text-decoration-none li-footer">Refund Policy</a>
                        </li>
                        <li class="">
                            <a href="#" class="text-decoration-none li-footer">Help</a>
                        </li>
                        <li class="">
                            <a href="#" class="text-decoration-none li-footer">Contact Us</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col-sm-6 col-md-4 mt-4 col-lg-3 text-center text-sm-start">
                <div class="Sitemap">
                    <h6 class="footer-heading text-white mb-0">Sitemap</h6>
                    <ul class="list-unstyled footer-link mt-3">
                        <li class="mb-1">
                            <a href="#" class="text-decoration-none li-footer">Lorem ipsum</a>
                        </li>
                        <li class="mb-1">
                            <a href="#" class="text-decoration-none li-footer">Lorem ipsum</a>
                        </li>
                        <li class="mb-1">
                            <a href="#" class="text-decoration-none li-footer">Lorem ipsum</a>
                        </li>
                        <li class="">
                            <a href="#" class="text-decoration-none li-footer">Lorem ipsum</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col-sm-6 col-md-4 mt-4 col-lg-2 text-center text-sm-start">
                <div class="social">
                    <h6 class="footer-heading text-white mb-0">Contact With Us</h6>
                    <ul class="list-inline mt-3">
                        <li class="list-inline-item social-list-footer">
                            <a href="#" class="btn-sm btn p-2"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_56_66)">
                                        <path d="M24 12C24 5.37258 18.6274 0 12 0C5.37258 0 0 5.37258 0 12C0 17.9895 4.3882 22.954 10.125 23.8542V15.4687H7.07812V12H10.125V9.35625C10.125 6.34875 11.9166 4.6875 14.6576 4.6875C15.9701 4.6875 17.3438 4.92187 17.3438 4.92187V7.875H15.8306C14.34 7.875 13.875 8.80008 13.875 9.75V12H17.2031L16.6711 15.4687H13.875V23.8542C19.6118 22.954 24 17.9895 24 12Z" fill="white" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_56_66">
                                            <rect width="24" height="24" fill="white" />
                                        </clipPath>
                                    </defs>
                                </svg></a>
                        </li>
                        <li class="list-inline-item social-list-footer">
                            <a href="#" class=" btn-sm btn  p-2"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_56_69)">
                                        <path d="M6.86096 6.15906L15.737 17.7641H17.097L8.32196 6.15906H6.86096Z" fill="white" />
                                        <path d="M12 0C5.373 0 0 5.373 0 12C0 18.627 5.373 24 12 24C18.627 24 24 18.627 24 12C24 5.373 18.627 0 12 0ZM15.063 19.232L11.193 14.177L6.771 19.232H4.313L10.046 12.678L4 4.768H9.062L12.556 9.389L16.599 4.768H19.054L13.693 10.894L20 19.231L15.063 19.232Z" fill="white" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_56_69">
                                            <rect width="24" height="24" fill="white" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </a>
                        </li>
                        <li class="list-inline-item social-list-footer">
                            <a href="#" class="btn-sm btn  p-2"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_56_73)">
                                        <path d="M23.498 6.18602C23.222 5.14702 22.409 4.32802 21.376 4.05002C19.505 3.54602 12 3.54602 12 3.54602C12 3.54602 4.495 3.54602 2.623 4.05002C1.591 4.32802 0.778 5.14602 0.502 6.18602C0 8.07002 0 12 0 12C0 12 0 15.93 0.502 17.814C0.778 18.853 1.591 19.672 2.624 19.95C4.495 20.454 12 20.454 12 20.454C12 20.454 19.505 20.454 21.377 19.95C22.409 19.672 23.222 18.854 23.499 17.814C24 15.93 24 12 24 12C24 12 24 8.07002 23.498 6.18602ZM9.546 15.569V8.43102L15.818 12L9.546 15.569Z" fill="white" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_56_73">
                                            <rect width="24" height="24" fill="white" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="text-center border-top mt-4 p-1 border-color-footer">
                <p class="my-2 li-footer">@2024 Qaum Tv, All Rights Reserved</p>
            </div>
        </div>
    </div>
</footer>