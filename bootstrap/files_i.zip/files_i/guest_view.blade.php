<div class="hovereffect-img position-relative">
    {{-- lable and video img  start--}}

    <div class="item slider-images-home">
        @if (@$item->is_custom_label === 1 && isset($item->label_id))
        <div class="image-label-album">
            <h3 class="label-heading text-white text-center mb-0">
                {{ $item->label->name }}
            </h3>
        </div>
       @endif

      
       <a href="{{ url('movie/guest/detail', $item->slug) }}">
        @isset($src)
            <img src="{{ $src }}" class="slider-images" alt="genre-image" />
        @endisset
       </a>
    </div>

    {{-- lable and video img end --}}
     
    {{-- Prop start --}}
    @if ($protip == 1)
        <div class="hoverr-opacity p-3">
        <!-- Movie Title -->
        <h3 class="moviename-heading text-white">{{ $item->title }}</h3>

        <!-- Movie Details -->
        <div class="d-flex align-items-center gap-3 flex-wrap">
            <h4 class="moviedetail-text text-white">{{ __('Tmdb Rating') }} {{ $item->rating }}</h4>
            <h4 class="moviedetail-text text-white">{{ $item->duration }} {{ __('Mins') }}</h4>
            <h4 class="moviedetail-text text-white">{{ $item->publish_year }}</h4>
            <h4 class="moviedetail-text text-white">{{ $item->maturity_rating }}</h4>
        </div>

        <!-- Read More Button -->
        <div class="mb-2">
            <a href="{{ url('movie/guest/detail', $item->slug) }}" class="read-button text-decoration-none">Read More</a>
        </div>

        <!-- Play Now and Watch Trailer Buttons -->
        {{-- <div class="mb-3">
            <div class="playNow-btn mb-3">
                <a href="#" class="text-decoration-none text-white d-flex align-items-center gap-3">
                    <span class="play-icon d-flex align-items-center justify-content-center">
                    <i class="fa-solid fa-play"></i>
                </span>
                <span>Play Now</span>
             </a>
            </div>

          <a href="#" class="trailer-button text-decoration-none border d-block">Watch Trailer</a>
         </div> --}}

         @if ($item->trailer_url != null || $item->trailer_url != '')
                <div class="mb-3">
                  <a href="{{ route('guestwatchtrailer', $item->id) }}" class="trailer-button text-decoration-none border d-block"> {{ __('Watch Trailer') }}</a>
                 </div>
            @endif

    <!-- Add to Watchlist Button -->
   
</div>

    @endif
    {{-- Prop end --}}
  </div>